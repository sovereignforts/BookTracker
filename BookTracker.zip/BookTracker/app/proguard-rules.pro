# Keep Room entities
-keep class com.booktracker.data.model.** { *; }

# Keep MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }
